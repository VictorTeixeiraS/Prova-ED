﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BalancedBrackets
{
    internal class Pilha
    {
        // atributos 
        private noPilha topo;

        // metodos
        public Pilha()
        {
            topo = null; // não foi inserido elemento
        }

        public bool isEmpty()
        {
            if (topo == null)
                return true;
            else
                return false;
        }

        public void push(int insertItem)
        {
            if (isEmpty()) // true
                topo = new noPilha(insertItem);
            else
            {

                noPilha novoNo = new noPilha(insertItem);
                novoNo.setNext(topo); // faz  o encadeamento

                topo = novoNo; // o topo agora aponta para mim -- this
            }
        } // fim do método push



        public int pop()
        {
            if (isEmpty())
            {
                Console.WriteLine("Pilha Vazia");
                return 0;
            }
            else
            {
                int temp = topo.getData();
                topo = topo.getNext();
                return (temp);
            }

        }

        public static Boolean areBracketsBalanced(String expr)
        {
            // Using ArrayDeque is faster than using Stack class 
            Stack<char> st = new Stack<char>();
            // Traversing the Expression 
            for (int i = 0; i < expr.Length; i++)
            {
                char x = expr[i];
                if (x == '(' || x == '[' || x == '{')
                {
                    // Push the element in the stack 
                    st.Push(x);
                    continue;
                }
                // IF current current character is not opening 
                // bracket, then it must be closing. So stack 
                // cannot be empty at this point. 
                if (st.Count == 0)
                    return false;
                char check;
                switch (x)
                {
                    case ')':
                        check = st.Pop();
                        if (check == '{' || check == '[')
                            return false;
                        break;
                    case '}':
                        check = st.Pop();
                        if (check == '(' || check == '[')
                            return false;
                        break;
                    case ']':
                        check = st.Pop();
                        if (check == '(' || check == '{')
                            return false;
                        break;
                }
            }
            // Check Empty Stack 
            return (st.Count == 0);
        }

         



    }
}
