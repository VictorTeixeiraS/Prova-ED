﻿namespace BalancedBrackets
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.Sentencetb = new System.Windows.Forms.TextBox();
            this.btVerifica = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(31, 32);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(56, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Sentença:";
            // 
            // Sentencetb
            // 
            this.Sentencetb.BackColor = System.Drawing.SystemColors.Info;
            this.Sentencetb.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Sentencetb.Location = new System.Drawing.Point(93, 25);
            this.Sentencetb.Name = "Sentencetb";
            this.Sentencetb.Size = new System.Drawing.Size(135, 20);
            this.Sentencetb.TabIndex = 1;
            // 
            // btVerifica
            // 
            this.btVerifica.BackColor = System.Drawing.Color.Chartreuse;
            this.btVerifica.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btVerifica.Location = new System.Drawing.Point(256, 22);
            this.btVerifica.Name = "btVerifica";
            this.btVerifica.Size = new System.Drawing.Size(75, 23);
            this.btVerifica.TabIndex = 2;
            this.btVerifica.Text = "VERIFIQUE!";
            this.btVerifica.UseVisualStyleBackColor = false;
            this.btVerifica.Click += new System.EventHandler(this.btVerifica_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ClientSize = new System.Drawing.Size(535, 78);
            this.Controls.Add(this.btVerifica);
            this.Controls.Add(this.Sentencetb);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox Sentencetb;
        private System.Windows.Forms.Button btVerifica;
    }
}

