﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BalancedBrackets
{
    internal class noPilha
    {
        // atributos
        private int data; // pilha de inteiros 
        private noPilha nextNo; // autoreferencia

        // metodos 
        public noPilha() // construtor default
        {
            data = 0;
            nextNo = null;
        }

        public noPilha(int valor)
        {
            data = valor;
            nextNo = null;
        }

        public noPilha(int valor, noPilha No)
        {
            data = valor;
            nextNo = No;
        }

        public int getData()
        {
            return data;
        }

        public void setData(int valor)
        {
            data = valor;
        }

        public noPilha getNext()
        {
            return nextNo;
        }

        public void setNext(noPilha newNo)
        {
            nextNo = newNo;
        }

    }
}
