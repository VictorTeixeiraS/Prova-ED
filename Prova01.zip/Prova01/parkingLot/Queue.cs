﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace parkingLot
{
    internal class Queue
    {
        private List<List<veiculo>> queue= new List<List<veiculo>>();

        public void Add(veiculo v)
        {
            if (queue.Count == 0)
            {
                List<veiculo> list = new List<veiculo>();
                list.Add(v);
                queue.Add(list);
            }
            else
            {
                bool added = false;
                for (int i = 0; i < queue.Count; i++)
                {
                    if (queue[i][0].placa == v.placa)
                    {
                        queue[i].Add(v);
                        added = true;
                        break;
                    }
                }
                if (!added)
                {
                    List<veiculo> list = new List<veiculo>();
                    list.Add(v);
                    queue.Add(list);
                }
            }
        }   

        public void Remove(veiculo v)
        {
            for (int i = 0; i < queue.Count; i++)
            {
                if (queue[i][0].placa == v.placa)
                {
                    queue[i].Remove(v);
                    if (queue[i].Count == 0)
                    {
                        queue.RemoveAt(i);
                    }
                    break;
                }
            }
        }

    }
  
}
