﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace parkingLot
{
    public partial class Form1 : Form
    {
        Queue l = new Queue();
        public Form1()
        {
            InitializeComponent();
        }

        private void Estacionar_Click(object sender, EventArgs e)
        {
            l.Add(placaCarro.Text);
            placaCarro.Text = string.Empty;
     
        }

        private void Retirar_Click(object sender, EventArgs e)
        {
            int temp = Convert.ToInt32(placaCarro.Text);

            // achar a referência de temp na lista
            Convert.ToInt32(l.Remove)(temp);
        }
    }
}
