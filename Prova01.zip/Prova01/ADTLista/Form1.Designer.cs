﻿namespace ADTLista
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.input = new System.Windows.Forms.TextBox();
            this.Insere = new System.Windows.Forms.Button();
            this.Remove = new System.Windows.Forms.Button();
            this.output = new System.Windows.Forms.TextBox();
            this.Imprime = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // input
            // 
            this.input.Location = new System.Drawing.Point(57, 37);
            this.input.Name = "input";
            this.input.Size = new System.Drawing.Size(100, 20);
            this.input.TabIndex = 0;
            // 
            // Insere
            // 
            this.Insere.Location = new System.Drawing.Point(435, 37);
            this.Insere.Name = "Insere";
            this.Insere.Size = new System.Drawing.Size(75, 23);
            this.Insere.TabIndex = 1;
            this.Insere.Text = "Insere";
            this.Insere.UseVisualStyleBackColor = true;
            this.Insere.Click += new System.EventHandler(this.Insere_Click);
            // 
            // Remove
            // 
            this.Remove.Location = new System.Drawing.Point(435, 76);
            this.Remove.Name = "Remove";
            this.Remove.Size = new System.Drawing.Size(75, 23);
            this.Remove.TabIndex = 2;
            this.Remove.Text = "Remove";
            this.Remove.UseVisualStyleBackColor = true;
            this.Remove.Click += new System.EventHandler(this.Remove_Click);
            // 
            // output
            // 
            this.output.Location = new System.Drawing.Point(57, 79);
            this.output.Name = "output";
            this.output.Size = new System.Drawing.Size(100, 20);
            this.output.TabIndex = 3;
            // 
            // Imprime
            // 
            this.Imprime.Location = new System.Drawing.Point(435, 116);
            this.Imprime.Name = "Imprime";
            this.Imprime.Size = new System.Drawing.Size(75, 23);
            this.Imprime.TabIndex = 4;
            this.Imprime.Text = "Imprime";
            this.Imprime.UseVisualStyleBackColor = true;
            this.Imprime.Click += new System.EventHandler(this.Imprime_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.Imprime);
            this.Controls.Add(this.output);
            this.Controls.Add(this.Remove);
            this.Controls.Add(this.Insere);
            this.Controls.Add(this.input);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox input;
        private System.Windows.Forms.Button Insere;
        private System.Windows.Forms.Button Remove;
        private System.Windows.Forms.TextBox output;
        private System.Windows.Forms.Button Imprime;
    }
}

