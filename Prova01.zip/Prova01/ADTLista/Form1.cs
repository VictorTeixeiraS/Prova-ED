﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ADTLista
{
    public partial class Form1 : Form
    {
        Lista l = new Lista();
        public Form1()
        {
            InitializeComponent();
        }

        private void Insere_Click(object sender, EventArgs e)
        {
            l.insere(Convert.ToInt32(input.Text));

        }

        private void Imprime_Click(object sender, EventArgs e)
        {
            
            output.Text = l.imprime();

        }

        private void Remove_Click(object sender, EventArgs e)
        {
            output.Text = l.remove(Convert.ToInt32(input.Text));
        }
    }
}
